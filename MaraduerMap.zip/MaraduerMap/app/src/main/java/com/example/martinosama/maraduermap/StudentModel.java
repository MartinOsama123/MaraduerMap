package com.example.martinosama.maraduermap;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class StudentModel implements Parcelable {
    private String name;
    private String password;
    private String lastKnownLocation;
    private boolean available;
    private ArrayList<Long> friends;
    private ArrayList<Long> pendingfriends;
    private ArrayList<Long> friendrequests;

    public StudentModel() {
    }



    public StudentModel(String name, String password, String lastKnownLocation, boolean available, ArrayList<Long> friends, ArrayList<Long> pendingfriends, ArrayList<Long> friendrequests) {
        this.name = name;
        this.password = password;
        this.lastKnownLocation = lastKnownLocation;
        this.available = available;
        this.friends = friends;
        this.pendingfriends = pendingfriends;
        this.friendrequests = friendrequests;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setLastKnownLocation(String lastKnownLocation) {
        this.lastKnownLocation = lastKnownLocation;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public ArrayList<Long> getFriends() {
        return friends;
    }

    public void setFriends(ArrayList<Long> friends) {
        this.friends = friends;
    }

    public ArrayList<Long> getPendingfriends() {
        return pendingfriends;
    }

    public void setPendingfriends(ArrayList<Long> pendingfriends) {
        this.pendingfriends = pendingfriends;
    }

    public ArrayList<Long> getFriendrequests() {
        return friendrequests;
    }

    public void setFriendrequests(ArrayList<Long> friendrequests) {
        this.friendrequests = friendrequests;
    }
    public String getName() {
        return name;
    }

    public boolean isAvailable() {
        return available;
    }

    public String getLastKnownLocation() { return lastKnownLocation; }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.password);
        dest.writeString(this.lastKnownLocation);
        dest.writeByte(this.available ? (byte) 1 : (byte) 0);
        dest.writeList(this.friends);
        dest.writeList(this.pendingfriends);
        dest.writeList(this.friendrequests);
    }

    protected StudentModel(Parcel in) {
        this.name = in.readString();
        this.password = in.readString();
        this.lastKnownLocation = in.readString();
        this.available = in.readByte() != 0;
        this.friends = new ArrayList<Long>();
        in.readList(this.friends, Long.class.getClassLoader());
        this.pendingfriends = new ArrayList<Long>();
        in.readList(this.pendingfriends, Long.class.getClassLoader());
        this.friendrequests = new ArrayList<Long>();
        in.readList(this.friendrequests, Long.class.getClassLoader());
    }

    public static final Parcelable.Creator<StudentModel> CREATOR = new Parcelable.Creator<StudentModel>() {
        @Override
        public StudentModel createFromParcel(Parcel source) {
            return new StudentModel(source);
        }

        @Override
        public StudentModel[] newArray(int size) {
            return new StudentModel[size];
        }
    };
}
